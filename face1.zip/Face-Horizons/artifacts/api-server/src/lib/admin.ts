export const ADMIN_NAME = process.env.ADMIN_NAME ?? "admin";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "";
export const SECONDARY_ADMIN_NAME = process.env.ADMIN_SECONDARY_NAME ?? "admin2";
export const SECONDARY_ADMIN_PASSWORD = process.env.ADMIN_SECONDARY_PASSWORD ?? "";

export type AdminRole = "primary" | "secondary";

export function getAdminRole(name: string, password: string): AdminRole | null {
  if (Boolean(ADMIN_PASSWORD) && name === ADMIN_NAME && password === ADMIN_PASSWORD) {
    return "primary";
  }
  if (
    Boolean(SECONDARY_ADMIN_PASSWORD) &&
    name === SECONDARY_ADMIN_NAME &&
    password === SECONDARY_ADMIN_PASSWORD
  ) {
    return "secondary";
  }
  return null;
}

export function isAdmin(name: string, password: string): boolean {
  return getAdminRole(name, password) !== null;
}
