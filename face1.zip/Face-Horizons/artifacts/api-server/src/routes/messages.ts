import { Router, type IRouter } from "express";
import { db, messagesTable, usersTable } from "@workspace/db";
import {
  ListConversationsBody,
  GetMessageThreadBody,
  SendMessageBody,
} from "@workspace/api-zod";
import { and, asc, desc, eq, or, sql } from "drizzle-orm";
import { verifyCredentials } from "./users";

const router: IRouter = Router();

router.post("/messages/conversations", async (req, res) => {
  const parsed = ListConversationsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Datos inválidos" });
    return;
  }

  const auth = await verifyCredentials(parsed.data.name, parsed.data.password);
  if (!auth.valid) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const me = parsed.data.name;

  const rows = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        eq(messagesTable.senderName, me),
        eq(messagesTable.recipientName, me),
      ),
    )
    .orderBy(desc(messagesTable.createdAt));

  const byPeer = new Map<
    string,
    {
      lastMessage: string;
      lastAt: Date;
      lastFromMe: boolean;
      unreadCount: number;
    }
  >();

  for (const m of rows) {
    const peer = m.senderName === me ? m.recipientName : m.senderName;
    const existing = byPeer.get(peer);
    if (!existing) {
      byPeer.set(peer, {
        lastMessage: m.content,
        lastAt: m.createdAt,
        lastFromMe: m.senderName === me,
        unreadCount: m.recipientName === me && !m.readAt ? 1 : 0,
      });
    } else if (m.recipientName === me && !m.readAt) {
      existing.unreadCount += 1;
    }
  }

  const peers = Array.from(byPeer.keys());
  const photoMap = new Map<string, string>();
  if (peers.length > 0) {
    const users = await db.select().from(usersTable);
    for (const u of users) {
      if (peers.includes(u.name)) photoMap.set(u.name, u.photo);
    }
  }

  const conversations = Array.from(byPeer.entries())
    .map(([peerName, info]) => ({
      peerName,
      peerPhoto: photoMap.get(peerName) ?? "",
      lastMessage: info.lastMessage,
      lastAt: info.lastAt.toISOString(),
      lastFromMe: info.lastFromMe,
      unreadCount: info.unreadCount,
    }))
    .sort((a, b) => (a.lastAt < b.lastAt ? 1 : -1));

  res.json(conversations);
});

router.post("/messages/thread", async (req, res) => {
  const parsed = GetMessageThreadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Datos inválidos" });
    return;
  }

  const auth = await verifyCredentials(parsed.data.name, parsed.data.password);
  if (!auth.valid) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const me = parsed.data.name;
  const peer = parsed.data.peerName;

  const rows = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        and(
          eq(messagesTable.senderName, me),
          eq(messagesTable.recipientName, peer),
        ),
        and(
          eq(messagesTable.senderName, peer),
          eq(messagesTable.recipientName, me),
        ),
      ),
    )
    .orderBy(asc(messagesTable.createdAt));

  await db
    .update(messagesTable)
    .set({ readAt: sql`now()` })
    .where(
      and(
        eq(messagesTable.senderName, peer),
        eq(messagesTable.recipientName, me),
        sql`${messagesTable.readAt} is null`,
      ),
    );

  res.json(
    rows.map((m) => ({
      id: m.id,
      senderName: m.senderName,
      recipientName: m.recipientName,
      content: m.content,
      createdAt: m.createdAt.toISOString(),
    })),
  );
});

router.post("/messages/send", async (req, res) => {
  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Datos inválidos" });
    return;
  }

  const auth = await verifyCredentials(
    parsed.data.senderName,
    parsed.data.password,
  );
  if (!auth.valid || auth.isAdmin) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const recipient = parsed.data.recipientName.trim();
  if (recipient === parsed.data.senderName) {
    res.status(400).json({ error: "No podés enviarte mensajes a vos mismo" });
    return;
  }

  const [recipientRow] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.name, recipient));
  if (!recipientRow) {
    res.status(404).json({ error: "Ese usuario no existe" });
    return;
  }

  const [created] = await db
    .insert(messagesTable)
    .values({
      senderName: parsed.data.senderName,
      recipientName: recipient,
      content: parsed.data.content,
    })
    .returning();

  if (!created) {
    res.status(500).json({ error: "No se pudo enviar el mensaje" });
    return;
  }

  res.status(201).json({
    id: created.id,
    senderName: created.senderName,
    recipientName: created.recipientName,
    content: created.content,
    createdAt: created.createdAt.toISOString(),
  });
});

export default router;
