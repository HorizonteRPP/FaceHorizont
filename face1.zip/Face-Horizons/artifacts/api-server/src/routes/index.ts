import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import postsRouter from "./posts";
import listingsRouter from "./listings";
import statsRouter from "./stats";
import messagesRouter from "./messages";
import commentsRouter from "./comments";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(usersRouter);
router.use(postsRouter);
router.use(listingsRouter);
router.use(statsRouter);
router.use(messagesRouter);
router.use(commentsRouter);
router.use(adminRouter);

export default router;
