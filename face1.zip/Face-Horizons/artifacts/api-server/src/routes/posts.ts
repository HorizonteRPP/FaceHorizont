import { Router, type IRouter } from "express";
import { db, postsTable } from "@workspace/db";
import {
  CreatePostBody,
  LikePostParams,
  DeletePostBody,
  DeletePostParams,
} from "@workspace/api-zod";
import { desc, eq, sql } from "drizzle-orm";
import { verifyCredentials } from "./users";

const router: IRouter = Router();

router.get("/posts", async (_req, res) => {
  const rows = await db
    .select()
    .from(postsTable)
    .orderBy(desc(postsTable.createdAt));

  res.json(
    rows.map((r) => ({
      id: r.id,
      authorName: r.authorName,
      authorPhoto: r.authorPhoto,
      message: r.message,
      imageUrl: r.imageUrl ?? null,
      likes: r.likes,
      createdAt: r.createdAt.toISOString(),
    })),
  );
});

router.post("/posts", async (req, res) => {
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Datos de publicación inválidos" });
    return;
  }

  const auth = await verifyCredentials(parsed.data.authorName, parsed.data.password);
  if (!auth.valid || auth.isAdmin) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const [created] = await db
    .insert(postsTable)
    .values({
      authorName: parsed.data.authorName,
      authorPhoto: auth.photo ?? "",
      message: parsed.data.message,
      imageUrl: parsed.data.imageUrl ?? null,
    })
    .returning();

  if (!created) {
    res.status(500).json({ error: "No se pudo crear la publicación" });
    return;
  }

  res.status(201).json({
    id: created.id,
    authorName: created.authorName,
    authorPhoto: created.authorPhoto,
    message: created.message,
    imageUrl: created.imageUrl ?? null,
    likes: created.likes,
    createdAt: created.createdAt.toISOString(),
  });
});

router.post("/posts/:id/like", async (req, res) => {
  const params = LikePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "ID inválido" });
    return;
  }

  const [updated] = await db
    .update(postsTable)
    .set({ likes: sql`${postsTable.likes} + 1` })
    .where(eq(postsTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Publicación no encontrada" });
    return;
  }

  res.json({
    id: updated.id,
    authorName: updated.authorName,
    authorPhoto: updated.authorPhoto,
    message: updated.message,
    imageUrl: updated.imageUrl ?? null,
    likes: updated.likes,
    createdAt: updated.createdAt.toISOString(),
  });
});

router.post("/posts/:id/delete", async (req, res) => {
  const params = DeletePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "ID inválido" });
    return;
  }
  const body = DeletePostBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: "Credenciales requeridas" });
    return;
  }

  const auth = await verifyCredentials(body.data.name, body.data.password);
  if (!auth.valid) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const [post] = await db
    .select()
    .from(postsTable)
    .where(eq(postsTable.id, params.data.id));

  if (!post) {
    res.status(404).json({ error: "Publicación no encontrada" });
    return;
  }

  if (!auth.isAdmin && post.authorName !== body.data.name) {
    res.status(403).json({ error: "Solo podés eliminar tus propias publicaciones" });
    return;
  }

  await db.delete(postsTable).where(eq(postsTable.id, params.data.id));

  res.json({ success: true });
});

export default router;
