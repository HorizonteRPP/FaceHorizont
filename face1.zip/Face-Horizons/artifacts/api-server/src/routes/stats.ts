import { Router, type IRouter } from "express";
import { db, postsTable, listingsTable } from "@workspace/db";
import { sql, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats/community", async (_req, res) => {
  const [{ totalPosts }] = (await db
    .select({ totalPosts: sql<number>`count(*)::int` })
    .from(postsTable)) as { totalPosts: number }[];

  const [{ totalListings }] = (await db
    .select({ totalListings: sql<number>`count(*)::int` })
    .from(listingsTable)) as { totalListings: number }[];

  const [{ uniqueAuthors }] = (await db
    .select({
      uniqueAuthors: sql<number>`count(distinct ${postsTable.authorName})::int`,
    })
    .from(postsTable)) as { uniqueAuthors: number }[];

  const [{ uniqueSellers }] = (await db
    .select({
      uniqueSellers: sql<number>`count(distinct ${listingsTable.sellerName})::int`,
    })
    .from(listingsTable)) as { uniqueSellers: number }[];

  const [{ postsToday }] = (await db
    .select({
      postsToday: sql<number>`count(*) filter (where ${postsTable.createdAt} >= now() - interval '24 hours')::int`,
    })
    .from(postsTable)) as { postsToday: number }[];

  const totalMembers = Math.max(
    uniqueAuthors + uniqueSellers,
    1,
  );

  res.json({
    totalMembers,
    totalPosts: totalPosts ?? 0,
    totalListings: totalListings ?? 0,
    postsToday: postsToday ?? 0,
  });
});

router.get("/stats/top-sellers", async (_req, res) => {
  const rows = (await db
    .select({
      sellerName: listingsTable.sellerName,
      sellerPhoto: sql<string>`max(${listingsTable.sellerPhoto})`,
      listingsCount: sql<number>`count(*)::int`,
    })
    .from(listingsTable)
    .groupBy(listingsTable.sellerName)
    .orderBy(desc(sql`count(*)`))
    .limit(5)) as {
    sellerName: string;
    sellerPhoto: string;
    listingsCount: number;
  }[];

  res.json(rows);
});

export default router;
