import { Router, type IRouter } from "express";
import { commentsTable, db, listingsTable, messagesTable, postsTable, usersTable } from "@workspace/db";
import { GetAdminStatusBody } from "@workspace/api-zod";
import { sql } from "drizzle-orm";
import { verifyCredentials } from "./users";

const router: IRouter = Router();

router.post("/admin/status", async (req, res) => {
  const parsed = GetAdminStatusBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Credenciales requeridas" });
    return;
  }

  const auth = await verifyCredentials(parsed.data.name, parsed.data.password);
  if (!auth.valid || !auth.isAdmin) {
    res.status(403).json({ error: "Solo los administradores pueden ver este panel" });
    return;
  }

  try {
    await db.execute(sql`select 1`);
    const [usersResult, postsResult, commentsResult, listingsResult, messagesResult] =
      await Promise.all([
        db.select({ count: sql<number>`count(*)` }).from(usersTable),
        db.select({ count: sql<number>`count(*)` }).from(postsTable),
        db.select({ count: sql<number>`count(*)` }).from(commentsTable),
        db.select({ count: sql<number>`count(*)` }).from(listingsTable),
        db.select({ count: sql<number>`count(*)` }).from(messagesTable),
      ]);

    const [users, posts, comments, listings, messages] = [
      usersResult[0]?.count,
      postsResult[0]?.count,
      commentsResult[0]?.count,
      listingsResult[0]?.count,
      messagesResult[0]?.count,
    ].map((count) => Number(count ?? 0));

    const supabaseConfigured = Boolean(
      process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY,
    );

    res.json({
      databaseConnected: true,
      databaseProvider: supabaseConfigured ? "Supabase" : "PostgreSQL del servidor",
      supabaseConfigured,
      users,
      posts,
      comments,
      listings,
      messages,
      checkedAt: new Date().toISOString(),
    });
  } catch {
    res.status(503).json({ error: "La base de datos no está disponible" });
  }
});

export default router;