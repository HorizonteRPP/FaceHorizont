import { Router, type IRouter } from "express";
import { db, listingsTable } from "@workspace/db";
import {
  CreateListingBody,
  DeleteListingBody,
  DeleteListingParams,
} from "@workspace/api-zod";
import { desc, eq } from "drizzle-orm";
import { verifyCredentials } from "./users";

const router: IRouter = Router();

router.get("/listings", async (_req, res) => {
  const rows = await db
    .select()
    .from(listingsTable)
    .orderBy(desc(listingsTable.createdAt));

  res.json(
    rows.map((r) => ({
      id: r.id,
      sellerName: r.sellerName,
      sellerPhoto: r.sellerPhoto,
      carName: r.carName,
      price: r.price,
      description: r.description,
      imageUrl: r.imageUrl ?? null,
      createdAt: r.createdAt.toISOString(),
    })),
  );
});

router.post("/listings", async (req, res) => {
  const parsed = CreateListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Datos del auto inválidos" });
    return;
  }

  const auth = await verifyCredentials(parsed.data.sellerName, parsed.data.password);
  if (!auth.valid || auth.isAdmin) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const [created] = await db
    .insert(listingsTable)
    .values({
      sellerName: parsed.data.sellerName,
      sellerPhoto: auth.photo ?? "",
      carName: parsed.data.carName,
      price: parsed.data.price,
      description: parsed.data.description,
      imageUrl: parsed.data.imageUrl ?? null,
    })
    .returning();

  if (!created) {
    res.status(500).json({ error: "No se pudo publicar el auto" });
    return;
  }

  res.status(201).json({
    id: created.id,
    sellerName: created.sellerName,
    sellerPhoto: created.sellerPhoto,
    carName: created.carName,
    price: created.price,
    description: created.description,
    imageUrl: created.imageUrl ?? null,
    createdAt: created.createdAt.toISOString(),
  });
});

router.post("/listings/:id/delete", async (req, res) => {
  const params = DeleteListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "ID inválido" });
    return;
  }
  const body = DeleteListingBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: "Credenciales requeridas" });
    return;
  }

  const auth = await verifyCredentials(body.data.name, body.data.password);
  if (!auth.valid) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const [listing] = await db
    .select()
    .from(listingsTable)
    .where(eq(listingsTable.id, params.data.id));

  if (!listing) {
    res.status(404).json({ error: "Publicación no encontrada" });
    return;
  }

  if (!auth.isAdmin && listing.sellerName !== body.data.name) {
    res.status(403).json({ error: "Solo podés eliminar tus propias publicaciones" });
    return;
  }

  await db.delete(listingsTable).where(eq(listingsTable.id, params.data.id));

  res.json({ success: true });
});

export default router;
