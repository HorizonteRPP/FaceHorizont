import { Router, type IRouter } from "express";
import { db, commentsTable } from "@workspace/db";
import {
  ListCommentsParams,
  CreateCommentParams,
  CreateCommentBody,
  DeleteCommentParams,
  DeleteCommentBody,
} from "@workspace/api-zod";
import { asc, eq } from "drizzle-orm";
import { verifyCredentials } from "./users";

const router: IRouter = Router();

router.get("/posts/:id/comments", async (req, res) => {
  const params = ListCommentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "ID inválido" });
    return;
  }
  const rows = await db
    .select()
    .from(commentsTable)
    .where(eq(commentsTable.postId, params.data.id))
    .orderBy(asc(commentsTable.createdAt));

  res.json(
    rows.map((c) => ({
      id: c.id,
      postId: c.postId,
      authorName: c.authorName,
      authorPhoto: c.authorPhoto,
      text: c.text,
      createdAt: c.createdAt.toISOString(),
    })),
  );
});

router.post("/posts/:id/comments", async (req, res) => {
  const params = CreateCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "ID inválido" });
    return;
  }
  const body = CreateCommentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: "Datos del comentario inválidos" });
    return;
  }

  const auth = await verifyCredentials(body.data.authorName, body.data.password);
  if (!auth.valid || auth.isAdmin) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const [created] = await db
    .insert(commentsTable)
    .values({
      postId: params.data.id,
      authorName: body.data.authorName,
      authorPhoto: auth.photo ?? "",
      text: body.data.text,
    })
    .returning();

  if (!created) {
    res.status(500).json({ error: "No se pudo crear el comentario" });
    return;
  }

  res.status(201).json({
    id: created.id,
    postId: created.postId,
    authorName: created.authorName,
    authorPhoto: created.authorPhoto,
    text: created.text,
    createdAt: created.createdAt.toISOString(),
  });
});

router.post("/comments/:id/delete", async (req, res) => {
  const params = DeleteCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "ID inválido" });
    return;
  }
  const body = DeleteCommentBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: "Credenciales requeridas" });
    return;
  }

  const auth = await verifyCredentials(body.data.name, body.data.password);
  if (!auth.valid) {
    res.status(401).json({ error: "Credenciales inválidas" });
    return;
  }

  const [comment] = await db
    .select()
    .from(commentsTable)
    .where(eq(commentsTable.id, params.data.id));

  if (!comment) {
    res.status(404).json({ error: "Comentario no encontrado" });
    return;
  }

  if (!auth.isAdmin && comment.authorName !== body.data.name) {
    res.status(403).json({ error: "Solo podés eliminar tus propios comentarios" });
    return;
  }

  await db.delete(commentsTable).where(eq(commentsTable.id, params.data.id));
  res.json({ success: true });
});

export default router;
