import { Router, type IRouter } from "express";
import { db, usersTable, postsTable, listingsTable, messagesTable, commentsTable } from "@workspace/db";
import { RegisterUserBody, LoginUserBody, UpdateUserBody } from "@workspace/api-zod";
import { eq, or } from "drizzle-orm";
import { ADMIN_NAME, getAdminRole, isAdmin } from "../lib/admin";

const router: IRouter = Router();

router.post("/users/register", async (req, res) => {
  const parsed = RegisterUserBody.safeParse(req.body);
  if (!parsed.success) {
    res
      .status(400)
      .json({ error: "Datos de registro inválidos" });
    return;
  }

  const trimmedName = parsed.data.name.trim();

  if (trimmedName.toLowerCase() === ADMIN_NAME.toLowerCase()) {
    res.status(409).json({ error: "Ese nombre está reservado" });
    return;
  }

  const existing = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.name, trimmedName));

  if (existing.length > 0) {
    res.status(409).json({ error: "Ese nombre ya está en uso" });
    return;
  }

  const [created] = await db
    .insert(usersTable)
    .values({
      name: trimmedName,
      password: parsed.data.password,
      photo: parsed.data.photo,
    })
    .returning();

  if (!created) {
    res.status(500).json({ error: "No se pudo crear el usuario" });
    return;
  }

  res.status(201).json({
    name: created.name,
    photo: created.photo,
  });
});

router.post("/users/login", async (req, res) => {
  const parsed = LoginUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Datos inválidos" });
    return;
  }

  const trimmedName = parsed.data.name.trim();

  const adminRole = getAdminRole(trimmedName, parsed.data.password);
  if (adminRole) {
    res.json({
      name: trimmedName,
      photo: "",
      isAdmin: true,
    });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.name, trimmedName));

  if (!user || user.password !== parsed.data.password) {
    res.status(401).json({ error: "Nombre o contraseña incorrectos" });
    return;
  }

  res.json({
    name: user.name,
    photo: user.photo,
    isAdmin: false,
  });
});

router.post("/users/update", async (req, res) => {
  const parsed = UpdateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Datos inválidos" });
    return;
  }

  const { name, password, newName, newPassword, newPhoto } = parsed.data;
  const trimmedName = name.trim();

  if (isAdmin(trimmedName, password)) {
    res.status(403).json({ error: "El admin no se puede modificar desde acá" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.name, trimmedName));

  if (!user || user.password !== password) {
    res.status(401).json({ error: "Contraseña actual incorrecta" });
    return;
  }

  let nextName = user.name;
  let nextPassword = user.password;
  let nextPhoto = user.photo;

  if (newName && newName.trim() && newName.trim() !== user.name) {
    const trimmedNew = newName.trim();
    if (trimmedNew.toLowerCase() === ADMIN_NAME.toLowerCase()) {
      res.status(409).json({ error: "Ese nombre está reservado" });
      return;
    }
    const existing = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.name, trimmedNew));
    if (existing.length > 0) {
      res.status(409).json({ error: "Ese nombre ya está en uso" });
      return;
    }
    nextName = trimmedNew;
  }

  if (newPassword && newPassword.length >= 4) {
    nextPassword = newPassword;
  }

  if (newPhoto && newPhoto.length > 0) {
    nextPhoto = newPhoto;
  }

  await db
    .update(usersTable)
    .set({ name: nextName, password: nextPassword, photo: nextPhoto })
    .where(eq(usersTable.id, user.id));

  if (nextName !== user.name) {
    await db.update(postsTable).set({ authorName: nextName }).where(eq(postsTable.authorName, user.name));
    await db.update(listingsTable).set({ sellerName: nextName }).where(eq(listingsTable.sellerName, user.name));
    await db.update(commentsTable).set({ authorName: nextName }).where(eq(commentsTable.authorName, user.name));
    await db.update(messagesTable).set({ senderName: nextName }).where(eq(messagesTable.senderName, user.name));
    await db.update(messagesTable).set({ recipientName: nextName }).where(eq(messagesTable.recipientName, user.name));
  }

  if (nextPhoto !== user.photo) {
    await db.update(postsTable).set({ authorPhoto: nextPhoto }).where(eq(postsTable.authorName, nextName));
    await db.update(listingsTable).set({ sellerPhoto: nextPhoto }).where(eq(listingsTable.sellerName, nextName));
    await db.update(commentsTable).set({ authorPhoto: nextPhoto }).where(eq(commentsTable.authorName, nextName));
  }

  res.json({ name: nextName, photo: nextPhoto, password: nextPassword });
});

export async function verifyCredentials(
  name: string,
  password: string,
): Promise<{ valid: boolean; isAdmin: boolean; photo?: string }> {
  if (isAdmin(name, password)) {
    return { valid: true, isAdmin: true };
  }
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.name, name));
  if (!user || user.password !== password) {
    return { valid: false, isAdmin: false };
  }
  return { valid: true, isAdmin: false, photo: user.photo };
}

export default router;
