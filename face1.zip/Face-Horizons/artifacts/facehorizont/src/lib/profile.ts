export interface Profile {
  name: string;
  password: string;
  photo?: string;
  isAdmin?: boolean;
}

export function getProfile(): Profile | null {
  const data = localStorage.getItem("facehorizont:profile");
  if (!data) return null;
  try {
    const parsed = JSON.parse(data);
    if (!parsed || typeof parsed.name !== "string" || typeof parsed.password !== "string" || !parsed.password) {
      localStorage.removeItem("facehorizont:profile");
      return null;
    }
    return parsed as Profile;
  } catch {
    localStorage.removeItem("facehorizont:profile");
    return null;
  }
}

export function setProfile(profile: Profile) {
  localStorage.setItem("facehorizont:profile", JSON.stringify(profile));
}

export function clearProfile() {
  localStorage.removeItem("facehorizont:profile");
}
