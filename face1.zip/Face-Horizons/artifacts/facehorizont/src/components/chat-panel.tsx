import { useState, useEffect, useRef } from "react";
import { MessageSquare, X, Send, ArrowLeft, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useListConversations, useGetMessageThread, useSendMessage } from "@workspace/api-client-react";
import { getProfile, clearProfile } from "@/lib/profile";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

let unread = 0;
const subs = new Set<(n: number) => void>();
export function getUnread() { return unread; }
export function setUnread(n: number) { unread = n; subs.forEach(f => f(n)); }
export function subscribeUnread(f: (n: number) => void) {
  subs.add(f);
  return () => {
    subs.delete(f);
  };
}

let openChatWithPeer: ((peerName: string, openingMessage?: string) => void) | null = null;
let openMessengerPanel: (() => void) | null = null;

export const initiateChat = (peerName: string, openingMessage?: string) => {
  if (openChatWithPeer) {
    openChatWithPeer(peerName, openingMessage);
  }
};

export const openMessenger = () => {
  if (openMessengerPanel) {
    openMessengerPanel();
  }
};

export function ChatPanel() {
  const [profile, setProfileState] = useState(() => getProfile());
  const [, setLocation] = useLocation();
  useEffect(() => {
    const id = setInterval(() => {
      const p = getProfile();
      setProfileState((prev) => {
        if (!prev && !p) return prev;
        if (!prev || !p) return p;
        if (prev.name === p.name && prev.password === p.password && prev.isAdmin === p.isAdmin) return prev;
        return p;
      });
    }, 2000);
    return () => clearInterval(id);
  }, []);
  const { toast } = useToast();

  const [isOpen, setIsOpen] = useState(false);
  const [activePeer, setActivePeer] = useState<string | null>(null);
  const [activePeerPhoto, setActivePeerPhoto] = useState<string>("");
  
  const [conversations, setConversations] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const listConversations = useListConversations();
  const getThread = useGetMessageThread();
  const sendMessage = useSendMessage();

  const handleAuthError = () => {
    clearProfile();
    toast({ title: "Tu sesión ya no es válida — volvé a ingresar", variant: "destructive" });
    setLocation("/register");
  };

  const fetchConversations = () => {
    if (!profile || profile.isAdmin || !isOpen) return;
    listConversations.mutate(
      { data: { name: profile.name, password: profile.password! } },
      {
        onSuccess: (data) => {
          setConversations(data);
          const totalUnread = data.reduce((sum: number, c: any) => sum + c.unreadCount, 0);
          setUnread(totalUnread);
        },
        onError: (err: any) => {
          if (err.status === 401) handleAuthError();
        }
      }
    );
  };

  const fetchThread = () => {
    if (!profile || profile.isAdmin || !activePeer || !isOpen) return;
    getThread.mutate(
      { data: { name: profile.name, password: profile.password!, peerName: activePeer } },
      {
        onSuccess: (data) => setMessages(data),
        onError: (err: any) => {
          if (err.status === 401) handleAuthError();
        }
      }
    );
  };

  useEffect(() => {
    if (isOpen && !activePeer && profile && !profile.isAdmin) {
      fetchConversations();
      const interval = setInterval(fetchConversations, 5000);
      return () => {
        clearInterval(interval);
      };
    }
    return undefined;
  }, [isOpen, activePeer, profile]);

  useEffect(() => {
    if (isOpen && activePeer && profile && !profile.isAdmin) {
      fetchThread();
      const interval = setInterval(fetchThread, 3000);
      return () => {
        clearInterval(interval);
      };
    }
    return undefined;
  }, [isOpen, activePeer, profile]);

  useEffect(() => {
    // Also poll globally if not open to update badge? Actually the prompt says: 
    // "When panel is OPEN, poll conversations every 5s" 
    // We can also poll unread when closed, let's poll globally every 15s if logged in.
    if (!isOpen && profile && !profile.isAdmin) {
      const fetchGlobalUnread = () => {
        listConversations.mutate(
          { data: { name: profile.name, password: profile.password! } },
          {
            onSuccess: (data) => {
              const totalUnread = data.reduce((sum: number, c: any) => sum + c.unreadCount, 0);
              setUnread(totalUnread);
            }
          }
        );
      };
      fetchGlobalUnread();
      const interval = setInterval(fetchGlobalUnread, 15000);
       return () => {
         clearInterval(interval);
       };
    }
    return undefined;
  }, [isOpen, profile]);

  useEffect(() => {
    openChatWithPeer = (peerName: string, openingMessage?: string) => {
      setIsOpen(true);
      setActivePeer(peerName);
      if (openingMessage) {
        setInput(openingMessage);
        setTimeout(() => textareaRef.current?.focus(), 100);
      }
    };
    openMessengerPanel = () => {
      setIsOpen(true);
      setActivePeer(null);
    };
    return () => {
      openChatWithPeer = null;
      openMessengerPanel = null;
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen, activePeer]);

  const handleSend = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || !profile || !activePeer) return;
    
    const text = input.trim().substring(0, 1000);
    sendMessage.mutate(
      { data: { senderName: profile.name, password: profile.password!, recipientName: activePeer, content: text } },
      {
        onSuccess: (newMsg) => {
          setMessages(prev => [...prev, newMsg]);
          setInput("");
          fetchThread(); // re-poll immediately
        },
        onError: (err: any) => {
          if (err.status === 401) handleAuthError();
          else toast({ title: "Error al enviar mensaje", variant: "destructive" });
        }
      }
    );
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!profile) return null;

  if (!isOpen) {
    if (profile.isAdmin) return null;
    
    const unreadCount = getUnread();
    return (
      <Button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg glow-hover z-50 p-0 bg-primary hover:bg-primary/90 text-primary-foreground"
      >
        <MessageSquare className="h-6 w-6" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-600 text-[10px] font-bold text-white border-2 border-background animate-pulse shadow-sm shadow-red-900/50">
            {unreadCount}
          </span>
        )}
      </Button>
    );
  }

  return (
    <div className="fixed right-6 bottom-0 z-50 w-full sm:w-[380px] h-[80vh] sm:h-[520px] bg-card border border-border rounded-t-xl shadow-2xl flex flex-col transition-all duration-300 transform translate-y-0 sm:translate-y-0 overflow-hidden">
      {profile.isAdmin ? (
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b border-border bg-input">
            <h3 className="font-bold text-lg">Mensajes</h3>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex-1 flex items-center justify-center p-6 text-center text-muted-foreground">
            Mensajes deshabilitado en modo administrador.
          </div>
        </div>
      ) : activePeer ? (
        <div className="flex flex-col h-full animate-in slide-in-from-right-8 duration-300">
          <div className="flex items-center gap-2 p-3 border-b border-border bg-input">
            <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 rounded-full" onClick={() => setActivePeer(null)}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Avatar className="h-8 w-8 border border-border shrink-0">
              <AvatarImage src={activePeerPhoto} className="object-cover" />
              <AvatarFallback className="text-xs bg-muted">{activePeer[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm truncate leading-tight">{activePeer}</p>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 rounded-full" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <ScrollArea className="flex-1 p-4 bg-background" ref={scrollRef}>
            <div className="space-y-4">
              {messages.length === 0 && !getThread.isPending && (
                <div className="text-center py-8 text-sm text-muted-foreground">
                  Comenzá la conversación con {activePeer}.
                </div>
              )}
              {messages.map((msg) => {
                const isMe = msg.senderName === profile.name;
                return (
                  <div key={msg.id} className={`flex flex-col ${isMe ? "items-end" : "items-start"}`}>
                    <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm whitespace-pre-wrap break-words ${isMe ? "bg-primary text-primary-foreground rounded-tr-sm" : "bg-input text-foreground rounded-tl-sm border border-border"}`}>
                      {msg.content}
                    </div>
                    <span className="text-[10px] text-muted-foreground mt-1 px-1">
                      {formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true, locale: es })}
                    </span>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
          
          <div className="p-3 border-t border-border bg-card">
            <form onSubmit={handleSend} className="flex gap-2 items-end">
              <Textarea 
                ref={textareaRef}
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                onKeyDown={handleKeyDown}
                placeholder="Escribe un mensaje..." 
                className="min-h-[40px] max-h-[120px] resize-none bg-input border-border text-sm"
                maxLength={1000}
              />
              <Button 
                type="submit" 
                size="icon" 
                className="h-10 w-10 rounded-full shrink-0 bg-primary hover:bg-primary/90 text-primary-foreground" 
                disabled={!input.trim() || sendMessage.isPending}
              >
                {sendMessage.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </form>
          </div>
        </div>
      ) : (
        <div className="flex flex-col h-full animate-in slide-in-from-left-8 duration-300">
          <div className="flex items-center justify-between p-4 border-b border-border bg-input">
            <h3 className="font-bold text-lg tracking-tight">Mensajes</h3>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <ScrollArea className="flex-1 bg-background">
            {conversations.length === 0 && !listConversations.isPending ? (
              <div className="p-6 text-center text-sm text-muted-foreground flex flex-col items-center justify-center h-full space-y-3">
                <MessageSquare className="h-10 w-10 text-muted-foreground/30" />
                <p>Todavía no tenés mensajes. Andá al Marketplace y tocá Contactar en una publicación.</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {conversations.map((conv) => (
                  <button 
                    key={conv.peerName} 
                    className="w-full p-4 flex items-center gap-3 hover:bg-input transition-colors text-left group"
                    onClick={() => {
                      setActivePeerPhoto(conv.peerPhoto);
                      setActivePeer(conv.peerName);
                    }}
                  >
                    <Avatar className="h-12 w-12 border border-border">
                      <AvatarImage src={conv.peerPhoto} className="object-cover" />
                      <AvatarFallback className="bg-muted">{conv.peerName[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline justify-between mb-1">
                        <span className="font-bold text-sm truncate pr-2 group-hover:text-primary transition-colors">{conv.peerName}</span>
                        <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                          {formatDistanceToNow(new Date(conv.lastAt), { addSuffix: true, locale: es })}
                        </span>
                      </div>
                      <p className={`text-xs truncate ${conv.unreadCount > 0 ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                        {conv.lastFromMe && <span className="text-muted-foreground mr-1">Tú:</span>}
                        {conv.lastMessage}
                      </p>
                    </div>
                    {conv.unreadCount > 0 && (
                      <div className="w-2.5 h-2.5 rounded-full bg-primary shrink-0"></div>
                    )}
                  </button>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      )}
    </div>
  );
}
