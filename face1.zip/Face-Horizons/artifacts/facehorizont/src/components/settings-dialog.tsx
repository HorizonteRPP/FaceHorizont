import { useState } from "react";
import { Settings, Loader2, Upload, Link as LinkIcon, KeyRound, User as UserIcon, Image as ImageIcon } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useUpdateUser } from "@workspace/api-client-react";
import { getProfile, setProfile, clearProfile } from "@/lib/profile";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { fileToBase64 } from "@/lib/utils";

export function SettingsDialog() {
  const [open, setOpen] = useState(false);
  const profile = getProfile();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const updateUser = useUpdateUser();

  // Photo state
  const [photoMode, setPhotoMode] = useState<"upload" | "url">("upload");
  const [photoUrl, setPhotoUrl] = useState("");
  const [photoPreview, setPhotoPreview] = useState("");

  // Password state
  const [pwCurrent, setPwCurrent] = useState("");
  const [pwNew, setPwNew] = useState("");
  const [pwConfirm, setPwConfirm] = useState("");

  // Username state
  const [newName, setNewName] = useState("");
  const [namePassword, setNamePassword] = useState("");

  if (!profile || profile.isAdmin) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      toast({ title: "La imagen es demasiado grande (máx 3MB)", variant: "destructive" });
      return;
    }
    try {
      const b64 = await fileToBase64(file);
      setPhotoPreview(b64);
    } catch (err) {
      console.error(err);
    }
  };

  const handleAuthError = () => {
    toast({ title: "Tu sesión ya no es válida — volvé a ingresar", variant: "destructive" });
    clearProfile();
    setLocation("/register");
  };

  const callUpdate = (
    payload: { newName?: string | null; newPassword?: string | null; newPhoto?: string | null },
    currentPassword: string,
    onDone: () => void,
  ) => {
    updateUser.mutate(
      { data: { name: profile.name, password: currentPassword, ...payload } },
      {
        onSuccess: (data) => {
          setProfile({
            name: data.name,
            password: data.password,
            photo: data.photo,
            isAdmin: false,
          });
          toast({ title: "Perfil actualizado" });
          onDone();
          setTimeout(() => window.location.reload(), 400);
        },
        onError: (err: any) => {
          if (err?.status === 401) {
            toast({ title: "Contraseña actual incorrecta", variant: "destructive" });
          } else if (err?.status === 409) {
            toast({ title: err?.data?.error ?? "Ese nombre ya está en uso", variant: "destructive" });
          } else {
            toast({ title: "No se pudo actualizar", variant: "destructive" });
          }
        },
      },
    );
  };

  const submitPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    const finalPhoto = photoMode === "upload" ? photoPreview : photoUrl.trim();
    if (!finalPhoto) {
      toast({ title: "Elegí una foto primero", variant: "destructive" });
      return;
    }
    if (!profile.password) {
      handleAuthError();
      return;
    }
    callUpdate({ newPhoto: finalPhoto }, profile.password, () => {
      setPhotoPreview("");
      setPhotoUrl("");
    });
  };

  const submitPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (pwNew.length < 4) {
      toast({ title: "La nueva contraseña debe tener al menos 4 caracteres", variant: "destructive" });
      return;
    }
    if (pwNew !== pwConfirm) {
      toast({ title: "Las contraseñas no coinciden", variant: "destructive" });
      return;
    }
    callUpdate({ newPassword: pwNew }, pwCurrent, () => {
      setPwCurrent("");
      setPwNew("");
      setPwConfirm("");
    });
  };

  const submitName = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newName.trim();
    if (trimmed.length < 2) {
      toast({ title: "El nombre debe tener al menos 2 caracteres", variant: "destructive" });
      return;
    }
    if (trimmed === profile.name) {
      toast({ title: "Ese ya es tu nombre actual", variant: "destructive" });
      return;
    }
    callUpdate({ newName: trimmed }, namePassword, () => {
      setNewName("");
      setNamePassword("");
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          title="Configuración"
          className="h-10 w-10 rounded-full text-muted-foreground hover:text-primary hover:bg-transparent"
        >
          <Settings className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-xl text-primary font-bold tracking-tight">Configuración</DialogTitle>
          <DialogDescription className="text-muted-foreground text-xs uppercase tracking-widest">
            Editá tu perfil
          </DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="photo" className="mt-2">
          <TabsList className="grid w-full grid-cols-3 bg-input">
            <TabsTrigger value="photo" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <ImageIcon className="h-4 w-4 mr-1.5" />
              Foto
            </TabsTrigger>
            <TabsTrigger value="password" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <KeyRound className="h-4 w-4 mr-1.5" />
              Clave
            </TabsTrigger>
            <TabsTrigger value="name" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <UserIcon className="h-4 w-4 mr-1.5" />
              Nombre
            </TabsTrigger>
          </TabsList>

          <TabsContent value="photo" className="mt-4">
            <form onSubmit={submitPhoto} className="space-y-4">
              <div className="flex justify-center">
                <Avatar className="h-24 w-24 border-2 border-primary">
                  {(photoMode === "upload" ? photoPreview : photoUrl) || profile.photo ? (
                    <AvatarImage src={(photoMode === "upload" ? photoPreview : photoUrl) || profile.photo} className="object-cover" />
                  ) : null}
                  <AvatarFallback>{profile.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
              </div>
              <Tabs value={photoMode} onValueChange={(v) => setPhotoMode(v as any)}>
                <TabsList className="grid w-full grid-cols-2 bg-input">
                  <TabsTrigger value="upload" className="data-[state=active]:bg-card">
                    <Upload className="h-3 w-3 mr-1.5" /> Subir
                  </TabsTrigger>
                  <TabsTrigger value="url" className="data-[state=active]:bg-card">
                    <LinkIcon className="h-3 w-3 mr-1.5" /> URL
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="upload" className="mt-2">
                  <Input type="file" accept="image/*" onChange={handleFileChange} className="bg-input border-border text-sm" />
                </TabsContent>
                <TabsContent value="url" className="mt-2">
                  <Input
                    placeholder="https://..."
                    value={photoUrl}
                    onChange={(e) => setPhotoUrl(e.target.value)}
                    className="bg-input border-border"
                  />
                </TabsContent>
              </Tabs>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled={updateUser.isPending}>
                {updateUser.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Cambiar foto"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="password" className="mt-4">
            <form onSubmit={submitPassword} className="space-y-3">
              <div className="space-y-2">
                <Label className="text-muted-foreground">Contraseña actual</Label>
                <Input type="password" value={pwCurrent} onChange={(e) => setPwCurrent(e.target.value)} className="bg-input border-border" autoComplete="current-password" />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">Nueva contraseña</Label>
                <Input type="password" value={pwNew} onChange={(e) => setPwNew(e.target.value)} className="bg-input border-border" autoComplete="new-password" />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">Repetir nueva contraseña</Label>
                <Input type="password" value={pwConfirm} onChange={(e) => setPwConfirm(e.target.value)} className="bg-input border-border" autoComplete="new-password" />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled={updateUser.isPending}>
                {updateUser.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Cambiar contraseña"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="name" className="mt-4">
            <form onSubmit={submitName} className="space-y-3">
              <div className="space-y-2">
                <Label className="text-muted-foreground">Nombre actual</Label>
                <Input disabled value={profile.name} className="bg-input border-border opacity-60" />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">Nuevo nombre de usuario</Label>
                <Input value={newName} onChange={(e) => setNewName(e.target.value)} className="bg-input border-border" placeholder="Ej. JohnDoe" />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">Contraseña actual (para confirmar)</Label>
                <Input type="password" value={namePassword} onChange={(e) => setNamePassword(e.target.value)} className="bg-input border-border" autoComplete="current-password" />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled={updateUser.isPending}>
                {updateUser.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Cambiar nombre"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
