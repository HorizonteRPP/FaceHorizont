import { useState } from "react";
import { useListComments, useCreateComment, useDeleteComment, getListCommentsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Trash2, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { getProfile, clearProfile } from "@/lib/profile";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface CommentsSectionProps {
  postId: number;
}

export function CommentsSection({ postId }: CommentsSectionProps) {
  const profile = getProfile();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [text, setText] = useState("");
  const [showAll, setShowAll] = useState(false);

  const { data: comments = [], isLoading } = useListComments(postId);
  const createComment = useCreateComment();
  const deleteComment = useDeleteComment();

  const queryKey = getListCommentsQueryKey(postId);
  const refresh = () => queryClient.invalidateQueries({ queryKey });

  const handleAuthError = () => {
    toast({ title: "Tu sesión ya no es válida — volvé a ingresar", variant: "destructive" });
    clearProfile();
    setLocation("/register");
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !profile || !profile.password || profile.isAdmin) return;
    createComment.mutate(
      { id: postId, data: { authorName: profile.name, password: profile.password, text: text.trim() } },
      {
        onSuccess: () => {
          setText("");
          refresh();
        },
        onError: (err: any) => {
          if (err?.status === 401) handleAuthError();
          else toast({ title: "No se pudo comentar", variant: "destructive" });
        },
      },
    );
  };

  const handleDelete = (id: number) => {
    if (!profile || !profile.password) return;
    deleteComment.mutate(
      { id, data: { name: profile.name, password: profile.password } },
      {
        onSuccess: () => refresh(),
        onError: (err: any) => {
          if (err?.status === 401) handleAuthError();
          else toast({ title: "No se pudo eliminar", variant: "destructive" });
        },
      },
    );
  };

  const visibleComments = showAll ? comments : comments.slice(-3);

  return (
    <div className="mt-3 pt-3 border-t border-border/50 space-y-3">
      {isLoading ? (
        <div className="flex items-center justify-center py-2">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          {comments.length > 3 && !showAll && (
            <button
              type="button"
              onClick={() => setShowAll(true)}
              className="text-xs text-muted-foreground hover:text-primary transition-colors"
            >
              Ver los {comments.length} comentarios
            </button>
          )}
          {visibleComments.map((c: any) => (
            <div key={c.id} className="flex items-start gap-2 group">
              <Avatar className="h-7 w-7 border border-border shrink-0">
                <AvatarImage src={c.authorPhoto} className="object-cover" />
                <AvatarFallback className="text-[10px]">{c.authorName[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="bg-input rounded-2xl px-3 py-2">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-xs font-bold text-foreground">{c.authorName}</span>
                    <span className="text-[10px] text-muted-foreground shrink-0">
                      {formatDistanceToNow(new Date(c.createdAt), { addSuffix: true, locale: es })}
                    </span>
                  </div>
                  <p className="text-sm text-foreground whitespace-pre-wrap break-words">{c.text}</p>
                </div>
              </div>
              {profile && (profile.isAdmin || profile.name === c.authorName) && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDelete(c.id)}
                  className="h-7 w-7 text-muted-foreground hover:text-primary opacity-0 group-hover:opacity-100 transition-opacity"
                  title="Eliminar comentario"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              )}
            </div>
          ))}
        </>
      )}

      {profile && !profile.isAdmin && profile.password && (
        <form onSubmit={handleSend} className="flex items-center gap-2 pt-1">
          <Avatar className="h-7 w-7 border border-border shrink-0">
            {profile.photo ? <AvatarImage src={profile.photo} className="object-cover" /> : null}
            <AvatarFallback className="text-[10px]">{profile.name[0]}</AvatarFallback>
          </Avatar>
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Escribí un comentario..."
            className="h-9 bg-input border-border text-sm rounded-full"
            maxLength={500}
            disabled={createComment.isPending}
          />
          <Button
            type="submit"
            size="icon"
            variant="ghost"
            disabled={!text.trim() || createComment.isPending}
            className="h-9 w-9 text-primary hover:bg-primary/10 shrink-0"
            title="Comentar"
          >
            {createComment.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>
      )}
    </div>
  );
}
