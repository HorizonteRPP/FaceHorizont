import { useState, useEffect, type FormEvent } from "react";
import { Link, useLocation } from "wouter";
import { getProfile, clearProfile, setProfile } from "@/lib/profile";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogOut, Home, Store, MessageSquare, ShieldCheck, Radio, LayoutDashboard, Siren } from "lucide-react";
import { SettingsDialog } from "@/components/settings-dialog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLoginUser } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { getUnread, subscribeUnread, openMessenger } from "@/components/chat-panel";

export function Header() {
  const profile = getProfile();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [adminError, setAdminError] = useState("");
  const [unreadCount, setUnreadCount] = useState(getUnread());

  useEffect(() => {
    const unsubscribe = subscribeUnread(setUnreadCount);
    return () => {
      unsubscribe();
    };
  }, []);

  const loginUser = useLoginUser();

  const handleLogout = () => {
    clearProfile();
    setLocation("/register");
  };

  const handleAdminLogin = (e: FormEvent) => {
    e.preventDefault();
    setAdminError("");
    if (!adminName.trim() || !adminPassword.trim()) return;

    loginUser.mutate({ data: { name: adminName.trim(), password: adminPassword } }, {
      onSuccess: (data) => {
        if (data.isAdmin) {
          setProfile({ name: data.name, password: adminPassword, photo: "", isAdmin: true });
          toast({ title: "Modo administrador activado" });
          setIsAdminOpen(false);
          window.location.reload();
        } else {
          setAdminError("Credenciales incorrectas.");
        }
      },
      onError: () => {
        setAdminError("Credenciales incorrectas.");
      }
    });
  };

  const navItems = [
    { href: "/home", label: "Inicio", icon: Home },
    { href: "/marketplace", label: "Mercado", icon: Store },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/80 bg-[hsl(var(--background)/.88)] backdrop-blur-xl">
      <div className="container flex h-[4.5rem] max-w-7xl items-center gap-4 px-4 md:px-6">
        <Link href="/home" className="group flex items-center gap-3 shrink-0 focus-ring" data-testid="link-brand">
          <span className="relative flex h-9 w-9 items-center justify-center overflow-hidden rounded-xl border border-primary/40 bg-primary/10 text-primary shadow-[0_0_24px_hsl(var(--primary)/.14)]">
            <span className="absolute inset-1 rounded-lg border border-primary/20" />
            <span className="font-display text-lg font-bold">F</span>
          </span>
          <span className="hidden font-display text-lg font-bold tracking-tight text-foreground sm:block">
            Face<span className="text-primary">Horizont</span>
          </span>
        </Link>

        <div className="hidden h-7 w-px bg-border md:block" />
        <nav className="flex flex-1 items-center gap-1 text-sm font-medium md:gap-2" aria-label="Navegación principal">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = location === href;
            return (
              <Link
                key={href}
                href={href}
                data-active={active}
                data-testid={`link-nav-${label.toLowerCase()}`}
                className={`group relative flex h-11 items-center gap-2 rounded-xl px-3 text-sm transition-all focus-ring md:px-4 ${active ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"}`}
              >
                <Icon className={`h-[18px] w-[18px] transition-colors ${active ? "text-primary" : "group-hover:text-primary"}`} />
                <span className="hidden sm:inline">{label}</span>
                <span className={`absolute inset-x-3 -bottom-[9px] h-0.5 origin-center rounded-full bg-primary transition-transform ${active ? "scale-x-100" : "scale-x-0 group-hover:scale-x-60"}`} />
              </Link>
            );
          })}

          {profile?.isAdmin && (
            <Link
              href="/admin"
              data-active={location === "/admin"}
              data-testid="link-nav-admin"
              className={`group relative flex h-11 items-center gap-2 rounded-xl px-3 text-sm transition-all focus-ring md:px-4 ${location === "/admin" ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"}`}
            >
              <LayoutDashboard className={`h-[18px] w-[18px] transition-colors ${location === "/admin" ? "text-primary" : "group-hover:text-primary"}`} />
              <span className="hidden lg:inline">Panel admin</span>
              <span className={`absolute inset-x-3 -bottom-[9px] h-0.5 origin-center rounded-full bg-primary transition-transform ${location === "/admin" ? "scale-x-100" : "scale-x-0 group-hover:scale-x-60"}`} />
            </Link>
          )}

          {profile?.isAdmin && profile.name.toLowerCase() === "admin2" && (
            <Link
              href="/admin"
              data-active={location === "/admin"}
              data-testid="link-nav-sos"
              className={`group relative flex h-11 items-center gap-2 rounded-xl border px-3 text-sm font-bold uppercase tracking-[0.12em] transition-all focus-ring md:px-4 ${location === "/admin" ? "border-primary/50 bg-primary/15 text-primary" : "border-primary/25 bg-primary/5 text-primary hover:border-primary/50 hover:bg-primary/10"}`}
            >
              <Siren className={`h-[18px] w-[18px] ${location === "/admin" ? "animate-pulse" : ""}`} />
              <span>SOS</span>
              <span className={`absolute inset-x-3 -bottom-[9px] h-0.5 origin-center rounded-full bg-primary transition-transform ${location === "/admin" ? "scale-x-100" : "scale-x-0 group-hover:scale-x-60"}`} />
            </Link>
          )}
          
          {profile && !profile.isAdmin && (
            <Button
              variant="ghost"
              size="sm"
              data-testid="button-open-messages"
              className="group relative h-11 gap-2 rounded-xl px-3 text-muted-foreground hover:bg-secondary/70 hover:text-foreground md:px-4"
              onClick={openMessenger}
            >
              <MessageSquare className="h-[18px] w-[18px] group-hover:text-primary" />
              <span className="hidden sm:inline">Mensajes</span>
              {unreadCount > 0 && (
                <span className="absolute right-1 top-1 flex min-h-4 min-w-4 items-center justify-center rounded-full border-2 border-[hsl(var(--background))] bg-primary px-1 text-[9px] font-bold text-primary-foreground">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </Button>
          )}

          <Dialog open={isAdminOpen} onOpenChange={setIsAdminOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" data-testid="button-admin-login" className="flex h-11 gap-2 rounded-xl px-3 text-muted-foreground hover:bg-secondary/70 hover:text-foreground">
                <ShieldCheck className="h-[18px] w-[18px]" />
                <span className="hidden lg:inline">Administración</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md bg-card border-border face-card">
              <DialogHeader>
                <DialogTitle className="text-xl text-primary font-bold tracking-tight">Acceso administrativo</DialogTitle>
                <DialogDescription className="text-muted-foreground text-xs uppercase tracking-widest">
                  Solo personal de Horizonte RP · admin o admin2
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleAdminLogin} className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="adminName" className="text-muted-foreground">Nombre</Label>
                  <Input 
                    id="adminName" 
                    value={adminName} 
                    onChange={(e) => setAdminName(e.target.value)} 
                    className="bg-input border-border text-foreground"
                    placeholder="admin o admin2"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="adminPassword" className="text-muted-foreground">Contraseña</Label>
                  <Input 
                    id="adminPassword" 
                    type="password" 
                    value={adminPassword} 
                    onChange={(e) => setAdminPassword(e.target.value)} 
                    className="bg-input border-border text-foreground"
                  />
                </div>
                {adminError && (
                  <div className="text-sm text-primary font-medium p-2 bg-primary/10 rounded border border-primary/20">
                    {adminError}
                  </div>
                )}
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled={loginUser.isPending}>
                  {loginUser.isPending ? "Verificando..." : "Ingresar"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </nav>
        <div className="ml-auto flex items-center gap-3">
          {profile?.isAdmin && (
            <div className="hidden items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-primary sm:flex">
              <Radio className="h-3 w-3 animate-pulse" />
              Admin
            </div>
          )}
          {profile && !profile.isAdmin && <SettingsDialog />}
          {profile && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" data-testid="button-profile-menu" className={`relative h-10 w-10 rounded-full border p-0 transition-transform hover:scale-105 ${profile.isAdmin ? 'border-primary shadow-[0_0_16px_hsl(var(--primary)/.2)]' : 'border-primary/60'}`}>
                  <Avatar className="h-9 w-9">
                    {!profile.isAdmin && profile.photo ? (
                      <AvatarImage src={profile.photo} alt={profile.name} className="object-cover" />
                    ) : null}
                    <AvatarFallback className={profile.isAdmin ? 'bg-primary text-white text-[10px] font-bold' : ''}>
                      {profile.isAdmin ? 'ADMIN' : profile.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48 bg-card border-border/50">
                <div className="flex items-center justify-start gap-3 border-b border-border/70 p-3">
                  <div className="h-2 w-2 rounded-full bg-primary status-dot" />
                  <div className="flex flex-col space-y-1 leading-none">
                    <p className="font-semibold text-foreground">{profile.name}</p>
                    {profile.isAdmin && <p className="text-[10px] text-red-500 uppercase tracking-wider">Staff</p>}
                  </div>
                </div>
                <DropdownMenuItem data-testid="menu-logout" className="m-1 cursor-pointer rounded-lg text-destructive focus:bg-destructive/10" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Cerrar sesión</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </header>
  );
}
