export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-background py-6 md:py-8">
      <div className="container max-w-6xl px-4 md:px-6 flex flex-col items-center justify-center gap-4">
        <p className="text-center text-sm text-muted-foreground uppercase tracking-widest font-mono">
          Derechos © Registrado para Horizonte RP
        </p>
      </div>
    </footer>
  );
}
