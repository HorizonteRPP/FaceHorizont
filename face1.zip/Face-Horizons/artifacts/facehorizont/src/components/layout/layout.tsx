import { useEffect } from "react";
import { useLocation } from "wouter";
import { Header } from "./header";
import { Footer } from "./footer";
import { ChatPanel } from "../chat-panel";
import { getProfile } from "@/lib/profile";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (location !== "/register" && !getProfile()) {
      setLocation("/register");
    }
  }, [location, setLocation]);

  const isRegister = location === "/register";

  return (
    <div className="relative min-h-[100dvh] flex flex-col text-foreground bg-background dark face-shell">
      {!isRegister && <Header />}
      <main className="flex-1 flex flex-col">
        {children}
      </main>
      {!isRegister && <Footer />}
      {!isRegister && <ChatPanel />}
    </div>
  );
}
