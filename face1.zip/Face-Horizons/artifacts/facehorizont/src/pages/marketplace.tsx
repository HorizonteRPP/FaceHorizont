import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { 
  useListListings, 
  useCreateListing, 
  useDeleteListing,
  useGetTopSellers,
  getListListingsQueryKey,
  getGetTopSellersQueryKey,
  getGetCommunityStatsQueryKey
} from "@workspace/api-client-react";
import { getProfile, clearProfile } from "@/lib/profile";
import { initiateChat } from "@/components/chat-panel";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Store, MessageSquare, CarFront, Trophy, DollarSign, Plus, Image as ImageIcon, Link as LinkIcon, Upload, X, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { fileToBase64 } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Marketplace() {
  const profile = getProfile();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [isOpen, setIsOpen] = useState(false);
  const [carName, setCarName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  
  const [imageMode, setImageMode] = useState<"upload" | "url">("upload");
  const [imageUrl, setImageUrl] = useState("");
  const [imagePreview, setImagePreview] = useState("");

  const { data: listings = [], isLoading: isLoadingListings } = useListListings();
  const { data: topSellers = [] } = useGetTopSellers();
  
  const createListing = useCreateListing();
  const deleteListing = useDeleteListing();

  const handleAuthError = () => {
    toast({ title: "Tu sesión ya no es válida — volvé a ingresar", variant: "destructive" });
    clearProfile();
    setLocation("/register");
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      toast({ title: "Error", description: "La imagen es demasiado grande. Límite de 3MB.", variant: "destructive" });
      return;
    }
    try {
      const b64 = await fileToBase64(file);
      setImagePreview(b64);
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!carName.trim() || !price || !description.trim() || !profile || !profile.password) return;
    
    let finalImageUrl = "";
    if (imageMode === "url" && imageUrl.trim()) finalImageUrl = imageUrl.trim();
    else if (imageMode === "upload" && imagePreview) finalImageUrl = imagePreview;

    createListing.mutate(
      { 
        data: { 
          sellerName: profile.name, 
          password: profile.password,
          carName: carName.trim(),
          price: Number(price),
          description: description.trim(),
          imageUrl: finalImageUrl || undefined
        } 
      },
      {
        onSuccess: () => {
          setIsOpen(false);
          setCarName("");
          setPrice("");
          setDescription("");
          setImageUrl("");
          setImagePreview("");
          queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetTopSellersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetCommunityStatsQueryKey() });
          toast({ title: "Vehículo publicado con éxito" });
        },
        onError: (err: any) => {
          if (err.status === 401) handleAuthError();
          else toast({ title: "Error al publicar", variant: "destructive" });
        }
      }
    );
  };

  const handleDelete = (id: number) => {
    if (!profile || !profile.password) return;
    deleteListing.mutate(
      { id, data: { name: profile.name, password: profile.password } },
      {
        onSuccess: () => {
          toast({ title: "Publicación eliminada" });
          queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetTopSellersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetCommunityStatsQueryKey() });
        },
        onError: (err: any) => {
          if (err.status === 401) handleAuthError();
          else toast({ title: "Error al eliminar", variant: "destructive" });
        }
      }
    );
  };

  const handleContact = (listing: any) => {
    if (!profile || profile.isAdmin) {
      toast({ title: "Iniciá sesión para enviar mensajes", variant: "destructive" });
      return;
    }
    if (listing.sellerName === profile.name) {
      toast({ title: "Es tu propia publicación" });
      return;
    }
    initiateChat(listing.sellerName, `Hola, me interesa tu ${listing.carName}`);
  };

  return (
    <div className="container max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row gap-8">
      {/* Sidebar with top sellers */}
      <div className="w-full md:w-64 order-2 md:order-1 space-y-6">
        <Card className="border-border bg-card shadow-sm sticky top-24">
          <CardHeader className="pb-4">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <Trophy className="h-5 w-5 text-muted-foreground" />
              Top Vendedores
            </h3>
          </CardHeader>
          <CardContent className="space-y-4">
            {topSellers.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No hay ventas registradas aún.</p>
            ) : (
              topSellers.map((seller, idx) => (
                <div key={seller.sellerName} className="flex items-center gap-3">
                  <div className="font-mono text-muted-foreground w-4 text-center">{idx + 1}</div>
                  <Avatar className="h-8 w-8 border border-border">
                    <AvatarImage src={seller.sellerPhoto} className="object-cover" />
                    <AvatarFallback>{seller.sellerName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-sm font-medium truncate text-foreground">{seller.sellerName}</p>
                    <p className="text-xs text-muted-foreground">{seller.listingsCount} pub.</p>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="flex-1 order-1 md:order-2 space-y-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-md">
              <Store className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Mercado de Vehículos</h1>
            </div>
          </div>
          
          {profile?.isAdmin ? (
             <div className="text-sm font-medium text-muted-foreground bg-card/50 px-4 py-2 rounded-md border border-border/50">
               Estás en modo administrador. Desactivá el modo administrador para publicar.
             </div>
          ) : (
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold gap-2 w-full sm:w-auto">
                  <Plus className="h-4 w-4" />
                  Publicar Vehículo
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px] bg-card border-border max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Nueva Publicación</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateListing} className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="carName">Vehículo (Modelo y marca)</Label>
                    <Input 
                      id="carName" 
                      placeholder="Ej. Karin Kuruma Custom" 
                      value={carName}
                      onChange={(e) => setCarName(e.target.value)}
                      required
                      maxLength={80}
                      className="bg-input border-border/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="price">Precio ($)</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="price" 
                        type="number" 
                        min="0"
                        placeholder="150000" 
                        className="pl-9 bg-input border-border/50"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Descripción</Label>
                    <Textarea 
                      id="description" 
                      placeholder="Motor al máximo, vidrios tintados, suspensión deportiva..." 
                      className="min-h-[80px] resize-none bg-input border-border/50"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      required
                      maxLength={500}
                    />
                  </div>

                  <div className="space-y-3 pt-2">
                    <Label>Foto del vehículo (Opcional)</Label>
                    <Tabs value={imageMode} onValueChange={(v) => setImageMode(v as "upload" | "url")} className="w-full">
                      <TabsList className="grid w-full grid-cols-2 bg-black/50 p-1">
                        <TabsTrigger value="upload" className="gap-2 text-xs data-[state=active]:bg-input data-[state=active]:text-foreground"><Upload className="w-3 h-3"/> Adjuntar foto</TabsTrigger>
                        <TabsTrigger value="url" className="gap-2 text-xs data-[state=active]:bg-input data-[state=active]:text-foreground"><LinkIcon className="w-3 h-3"/> Pegar URL</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="upload" className="space-y-2 mt-2">
                        <div className="relative">
                          <Input 
                            id="photoFile" 
                            type="file" 
                            accept="image/*"
                            onChange={handleFileChange}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                          />
                          <div className="flex items-center justify-between px-3 py-2 bg-input border border-border/50 rounded-md text-sm">
                            <span className="bg-muted px-2 py-1 rounded text-xs font-medium mr-2">Seleccionar archivo</span>
                            <span className="text-muted-foreground truncate text-xs flex-1">
                              {imagePreview ? "Imagen seleccionada" : "Sin archivos seleccionados"}
                            </span>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="url" className="space-y-2 mt-2">
                        <Input 
                          id="photoUrl" 
                          type="url" 
                          placeholder="https://ejemplo.com/foto.jpg" 
                          value={imageUrl} 
                          onChange={(e) => setImageUrl(e.target.value)} 
                          className="bg-input border-border/50"
                        />
                      </TabsContent>
                    </Tabs>
                    
                    {((imageMode === "url" && imageUrl) || (imageMode === "upload" && imagePreview)) && (
                      <div className="mt-2 flex justify-center animate-in fade-in">
                        <div className="relative w-full aspect-video rounded-md border border-border overflow-hidden bg-black">
                          <img 
                            src={imageMode === "upload" ? imagePreview : imageUrl} 
                            alt="Preview" 
                            className="w-full h-full object-cover" 
                          />
                          <Button 
                            variant="destructive" 
                            size="icon" 
                            className="absolute top-2 right-2 h-6 w-6 rounded-full opacity-80 hover:opacity-100 bg-primary"
                            onClick={() => {
                              setImageUrl("");
                              setImagePreview("");
                            }}
                            type="button"
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>

                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold mt-4" disabled={createListing.isPending}>
                    {createListing.isPending ? 'Publicando...' : 'Publicar'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Listings Grid */}
        {isLoadingListings ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array(6).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse border-border h-[400px]"></Card>
            ))}
          </div>
        ) : listings.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground border border-dashed border-border rounded-xl bg-card">
            <CarFront className="h-12 w-12 mx-auto mb-4 opacity-20" />
            <p>No hay vehículos en venta en este momento.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {listings.map((listing) => (
              <Card key={listing.id} className="flex flex-col border-border bg-card overflow-hidden group hover:border-border/80 transition-colors">
                <div className="aspect-[4/3] w-full relative bg-black border-b border-border">
                  {listing.imageUrl ? (
                    <img src={listing.imageUrl} alt={listing.carName} className="w-full h-full object-cover" loading="lazy" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-black text-muted">
                      <CarFront className="w-16 h-16 opacity-50" />
                    </div>
                  )}
                  
                  {(profile?.isAdmin || profile?.name === listing.sellerName) && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="destructive" 
                          size="icon" 
                          title="Eliminar publicación"
                          className={`absolute top-2 right-2 h-9 w-9 shadow-lg transition-all ${profile?.isAdmin ? 'bg-primary' : 'bg-black/50 hover:bg-black/80 border border-border'}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-card border-border">
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar vehículo?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción no se puede deshacer. La publicación de venta se eliminará permanentemente.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDelete(listing.id)} className="bg-primary text-primary-foreground hover:bg-primary/90">
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>

                <div className="flex items-center gap-3 w-full p-3 bg-input border-b border-border">
                  <Avatar className="h-6 w-6 border border-border">
                    <AvatarImage src={listing.sellerPhoto} className="object-cover" />
                    <AvatarFallback>{listing.sellerName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-xs font-medium truncate text-foreground">{listing.sellerName}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {formatDistanceToNow(new Date(listing.createdAt), { addSuffix: true, locale: es })}
                    </p>
                  </div>
                </div>

                <CardContent className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-lg mb-1 leading-tight line-clamp-2 text-foreground">{listing.carName}</h4>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                      {listing.description}
                    </p>
                  </div>
                  <div className="mt-auto">
                    <span className="text-xl font-bold font-sans text-primary block">
                      ${listing.price.toLocaleString('en-US')}
                    </span>
                  </div>
                </CardContent>

                <CardFooter className="p-4 pt-0">
                  <Button 
                    variant="secondary" 
                    className="w-full gap-2 bg-input hover:bg-muted text-foreground border border-border"
                    onClick={() => handleContact(listing)}
                  >
                    <MessageSquare className="h-4 w-4" />
                    Contactar
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
