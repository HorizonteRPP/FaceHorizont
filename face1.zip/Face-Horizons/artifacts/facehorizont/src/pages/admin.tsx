import { useEffect, useState } from "react";
import { Redirect, useLocation } from "wouter";
import { useGetAdminStatus } from "@workspace/api-client-react";
import { getProfile, clearProfile } from "@/lib/profile";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Activity,
  CarFront,
  CheckCircle2,
  Database,
  FileText,
  Loader2,
  MessageSquare,
  RefreshCw,
  Server,
  ShieldCheck,
  Siren,
  Users,
  XCircle,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

const metrics = [
  { key: "users", label: "Usuarios", icon: Users },
  { key: "posts", label: "Publicaciones", icon: FileText },
  { key: "comments", label: "Comentarios", icon: MessageSquare },
  { key: "listings", label: "Vehículos", icon: CarFront },
  { key: "messages", label: "Mensajes", icon: Activity },
] as const;

export default function Admin() {
  const profile = getProfile();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const status = useGetAdminStatus();
  const [checkedAt, setCheckedAt] = useState<Date | null>(null);

  const loadStatus = () => {
    if (!profile?.isAdmin || !profile.password) return;
    status.mutate(
      { data: { name: profile.name, password: profile.password } },
      {
        onSuccess: (data) => setCheckedAt(new Date(data.checkedAt)),
        onError: (error: any) => {
          if (error?.status === 401 || error?.status === 403) {
            clearProfile();
            toast({ title: "Acceso administrativo no válido", variant: "destructive" });
            setLocation("/register");
          } else {
            toast({ title: "No se pudo consultar el estado de la base", variant: "destructive" });
          }
        },
      },
    );
  };

  useEffect(() => {
    loadStatus();
  }, []);

  if (!profile?.isAdmin) {
    return <Redirect to="/home" />;
  }

  const data = status.data;

  return (
    <div className="face-shell face-grid flex-1">
      <div className="container mx-auto max-w-6xl space-y-6 px-4 py-8 md:px-6">
        <section className="face-card stagger-in rounded-2xl border border-primary/20 bg-card/90 p-6 md:p-8">
          <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-primary">
                <ShieldCheck className="h-4 w-4" />
                Área protegida
              </div>
              <h1 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl">
                SOS · Centro de control
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
                Revisa la salud de la plataforma, la conexión de datos y el movimiento de la comunidad desde un solo lugar.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button
                onClick={() => document.getElementById("supabase-status")?.scrollIntoView({ behavior: "smooth", block: "center" })}
                variant="outline"
                className="gap-2 border-border/80 bg-card/80 hover:border-primary/40 hover:bg-primary/10"
                data-testid="button-supabase-status"
              >
                <span className={`h-2.5 w-2.5 rounded-full ${data?.supabaseConfigured ? "bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,.8)]" : "bg-red-500 shadow-[0_0_12px_rgba(239,68,68,.75)]"}`} />
                SUPABASE
              </Button>
              <Button
                onClick={loadStatus}
                disabled={status.isPending}
                variant="outline"
                className="gap-2 border-primary/30 bg-primary/5 hover:bg-primary/10"
                data-testid="button-refresh-admin-status"
              >
                {status.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                Actualizar estado
              </Button>
            </div>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2">
          <Card id="supabase-status" className="face-card face-card-hover border-border/80 bg-card/90">
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="flex items-center gap-2 text-base">
                <Database className="h-5 w-5 text-primary" />
                Base de datos
              </CardTitle>
              {data?.databaseConnected ? (
                <Badge className="gap-1 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/15">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Conectada
                </Badge>
              ) : (
                <Badge variant="destructive" className="gap-1">
                  <XCircle className="h-3.5 w-3.5" /> Sin conexión
                </Badge>
              )}
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 rounded-xl border border-border/70 bg-input/60 p-3">
                <Server className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">Proveedor actual</p>
                  <p className="font-semibold text-foreground">{data?.databaseProvider ?? "Consultando..."}</p>
                </div>
              </div>
              <p className="text-xs leading-5 text-muted-foreground">
                Esta comprobación consulta directamente la base del servidor y no depende del navegador.
              </p>
            </CardContent>
          </Card>

          <Card className="face-card face-card-hover border-border/80 bg-card/90">
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="flex items-center gap-2 text-base">
                <Activity className="h-5 w-5 text-primary" />
                Supabase
              </CardTitle>
              {data?.supabaseConfigured ? (
                <Badge className="gap-1 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/15">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Conectada
                </Badge>
              ) : (
                <Badge variant="outline" className="gap-1 border-red-500/30 text-red-300">
                  <XCircle className="h-3.5 w-3.5" /> Sin conexión
                </Badge>
              )}
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-6 text-muted-foreground">
                {data?.supabaseConfigured
                  ? "Supabase está conectada y disponible para el proyecto."
                  : "Supabase no está conectada todavía. El punto rojo indica el estado actual."}
              </p>
              <p className="mt-3 text-xs text-muted-foreground">
                La conexión se puede activar sin guardar claves en el repositorio.
              </p>
            </CardContent>
          </Card>
        </section>

        <section>
          <div className="mb-3 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-primary">Resumen de datos</p>
              <h2 className="mt-1 font-display text-2xl font-bold text-foreground">Actividad de Horizonte RP</h2>
            </div>
            {checkedAt && (
              <span className="hidden text-xs text-muted-foreground sm:block">
                Revisado {formatDistanceToNow(checkedAt, { addSuffix: true, locale: es })}
              </span>
            )}
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {metrics.map(({ key, label, icon: Icon }, index) => (
              <Card
                key={key}
                className={`stagger-in-${Math.min(index + 1, 4)} face-card-hover border-border/80 bg-card/90`}
                data-testid={`card-admin-metric-${key}`}
              >
                <CardContent className="p-5">
                  <div className="mb-4 flex items-center justify-between">
                    <Icon className="h-5 w-5 text-primary" />
                    <span className="font-data text-2xl font-bold text-foreground">{data?.[key] ?? "—"}</span>
                  </div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <Card className="border-border/80 bg-card/70">
          <CardContent className="flex flex-col gap-3 p-5 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-primary" />
              Sesión administrativa activa como <span className="font-semibold text-foreground">{profile.name}</span>
            </div>
            <span className="text-xs">Las acciones destructivas permanecen desactivadas.</span>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}