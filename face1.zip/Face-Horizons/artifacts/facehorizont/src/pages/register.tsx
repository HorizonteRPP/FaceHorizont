import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { setProfile, getProfile } from "@/lib/profile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserCircle2, Image as ImageIcon, Link as LinkIcon, Upload } from "lucide-react";
import { useRegisterUser, useLoginUser } from "@workspace/api-client-react";
import { fileToBase64 } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [mode, setMode] = useState<"login" | "register">("register");
  
  // Form state
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [photoMode, setPhotoMode] = useState<"url" | "upload">("upload");
  const [photoUrl, setPhotoUrl] = useState("");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState("");

  const registerUser = useRegisterUser();
  const loginUser = useLoginUser();

  useEffect(() => {
    if (getProfile()) {
      setLocation("/home");
    }
  }, [setLocation]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      toast({ title: "Error", description: "La imagen es demasiado grande. Límite de 3MB.", variant: "destructive" });
      return;
    }
    setPhotoFile(file);
    try {
      const b64 = await fileToBase64(file);
      setPhotoPreview(b64);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (!name.trim() || !password.trim()) return;

    if (mode === "register") {
      let finalPhoto = "";
      if (photoMode === "url") {
        finalPhoto = photoUrl.trim();
      } else if (photoPreview) {
        finalPhoto = photoPreview;
      }
      
      if (!finalPhoto) {
        setErrorMsg("Debes proporcionar una foto de perfil.");
        return;
      }

      registerUser.mutate({ data: { name: name.trim(), password, photo: finalPhoto } }, {
        onSuccess: () => {
          setProfile({ name: name.trim(), password, photo: finalPhoto, isAdmin: false });
          setLocation("/home");
        },
        onError: (err: any) => {
          if (err?.error === "Username already taken") {
            setErrorMsg("Ese nombre ya está en uso");
          } else {
            setErrorMsg("Error al registrarse. Intenta nuevamente.");
          }
        }
      });
    } else {
      loginUser.mutate({ data: { name: name.trim(), password } }, {
        onSuccess: (data) => {
          setProfile({ name: data.name, password, photo: data.photo, isAdmin: data.isAdmin });
          setLocation("/home");
        },
        onError: () => {
          setErrorMsg("Credenciales incorrectas.");
        }
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#0a0a0a]">
      <Card className="w-full max-w-[420px] border-border bg-card shadow-2xl animate-in fade-in zoom-in duration-500">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-muted/20 flex items-center justify-center border border-border">
              <UserCircle2 className="h-10 w-10 text-muted-foreground" strokeWidth={1} />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight text-primary">FaceHorizont</CardTitle>
          <CardDescription className="text-muted-foreground uppercase tracking-widest text-xs mt-1">
            {mode === "register" ? "Registro de nuevo usuario" : "Ingreso de usuario"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-xs font-semibold text-muted-foreground">Nombre de personaje</Label>
              <Input 
                id="name" 
                autoComplete="username"
                placeholder="Ej. John Doe" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                required 
                className="bg-input border-border/50"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-xs font-semibold text-muted-foreground">Contraseña</Label>
              <Input 
                id="password" 
                type="password"
                autoComplete={mode === "register" ? "new-password" : "current-password"}
                placeholder="••••••••" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
                className="bg-input border-border/50"
              />
            </div>

            {mode === "register" && (
              <div className="space-y-3 pt-2">
                <Label className="text-xs font-semibold text-muted-foreground">Foto de perfil</Label>
                <Tabs value={photoMode} onValueChange={(v) => setPhotoMode(v as "url" | "upload")} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-black/50 p-1">
                    <TabsTrigger value="upload" className="gap-2 text-xs data-[state=active]:bg-input data-[state=active]:text-foreground"><Upload className="w-3 h-3"/> Adjuntar foto</TabsTrigger>
                    <TabsTrigger value="url" className="gap-2 text-xs data-[state=active]:bg-input data-[state=active]:text-foreground"><LinkIcon className="w-3 h-3"/> Pegar URL</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="upload" className="mt-3">
                    <div className="relative">
                      <Input 
                        id="photoFile" 
                        type="file" 
                        accept="image/*"
                        onChange={handleFileChange}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      />
                      <div className="flex items-center justify-between px-3 py-2 bg-input border border-border/50 rounded-md text-sm">
                        <span className="bg-muted px-2 py-1 rounded text-xs font-medium mr-2">Seleccionar archivo</span>
                        <span className="text-muted-foreground truncate text-xs flex-1">
                          {photoFile ? photoFile.name : "Sin archivos seleccionados"}
                        </span>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="url" className="mt-3">
                    <Input 
                      id="photoUrl" 
                      type="url" 
                      placeholder="https://ejemplo.com/foto.jpg" 
                      value={photoUrl} 
                      onChange={(e) => {
                        setPhotoUrl(e.target.value);
                        setPhotoPreview(e.target.value);
                      }} 
                      className="bg-input border-border/50"
                    />
                  </TabsContent>
                </Tabs>
                
                {photoPreview && (
                  <div className="mt-4 flex justify-center animate-in fade-in">
                    <div className="relative w-20 h-20 rounded-full border border-border overflow-hidden">
                      <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  </div>
                )}
              </div>
            )}

            {errorMsg && (
              <div className="text-sm text-destructive font-medium text-center p-2 bg-destructive/10 rounded border border-destructive/20 animate-in shake">
                {errorMsg}
              </div>
            )}

            <Button type="submit" className="w-full glow-hover mt-6 bg-primary hover:bg-primary/90 text-white font-semibold">
              {mode === "register" ? "Registrarse" : "Ingresar"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center pt-2 pb-6">
          {mode === "register" ? (
            <button className="text-muted-foreground text-sm hover:text-foreground transition-colors" onClick={() => setMode("login")}>
              ¿Ya tenés cuenta? <span className="text-primary font-medium">Iniciar sesión</span>
            </button>
          ) : (
            <button className="text-muted-foreground text-sm hover:text-foreground transition-colors" onClick={() => setMode("register")}>
              ¿No tenés cuenta? <span className="text-primary font-medium">Registrarse</span>
            </button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
