import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useListPosts, 
  useCreatePost, 
  useLikePost, 
  useDeletePost,
  useGetCommunityStats,
  getListPostsQueryKey,
  getGetCommunityStatsQueryKey
} from "@workspace/api-client-react";
import { getProfile, clearProfile } from "@/lib/profile";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MessageCircle, Send, Users, Activity, Car, Hash, Image as ImageIcon, X, Trash2, Link as LinkIcon, Upload, Radio, Sparkles, Clock3, ArrowUpRight } from "lucide-react";
import { CommentsSection } from "@/components/comments-section";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fileToBase64 } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Home() {
  const [, setLocation] = useLocation();
  const profile = getProfile();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [message, setMessage] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [imageMode, setImageMode] = useState<"upload" | "url">("upload");
  const [imagePreview, setImagePreview] = useState("");
  const [isImagePopoverOpen, setIsImagePopoverOpen] = useState(false);

  const { data: posts = [], isLoading: isLoadingPosts } = useListPosts();
  const { data: stats } = useGetCommunityStats();
  
  const createPost = useCreatePost();
  const likePost = useLikePost();
  const deletePost = useDeletePost();

  const handleAuthError = () => {
    toast({ title: "Tu sesión ya no es válida — volvé a ingresar", variant: "destructive" });
    clearProfile();
    setLocation("/register");
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      toast({ title: "Error", description: "La imagen es demasiado grande. Límite de 3MB.", variant: "destructive" });
      return;
    }
    try {
      const b64 = await fileToBase64(file);
      setImagePreview(b64);
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreatePost = () => {
    if (!message.trim() || !profile || !profile.password) return;
    
    let finalImageUrl = "";
    if (imageMode === "url" && imageUrl.trim()) finalImageUrl = imageUrl.trim();
    else if (imageMode === "upload" && imagePreview) finalImageUrl = imagePreview;

    createPost.mutate(
      { 
        data: { 
          authorName: profile.name, 
          password: profile.password, 
          message: message.trim(),
          imageUrl: finalImageUrl || undefined
        } 
      },
      {
        onSuccess: () => {
          setMessage("");
          setImageUrl("");
          setImagePreview("");
          queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetCommunityStatsQueryKey() });
        },
        onError: (err: any) => {
          if (err.status === 401) handleAuthError();
          else toast({ title: "Error al publicar", variant: "destructive" });
        }
      }
    );
  };

  const handleLike = (id: number) => {
    likePost.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
      }
    });
  };

  const handleDelete = (id: number) => {
    if (!profile || !profile.password) return;
    deletePost.mutate(
      { id, data: { name: profile.name, password: profile.password } },
      {
        onSuccess: () => {
          toast({ title: "Publicación eliminada" });
          queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetCommunityStatsQueryKey() });
        },
        onError: (err: any) => {
          if (err.status === 401) handleAuthError();
          else toast({ title: "Error al eliminar", variant: "destructive" });
        }
      }
    );
  };

  return (
    <div className="face-grid min-h-full flex-1">
      <div className="container mx-auto max-w-7xl px-4 pb-16 pt-6 md:px-6 md:pt-10">
        <section className="stagger-in relative mb-8 overflow-hidden rounded-2xl border border-primary/20 bg-card/90 p-5 face-card md:p-7">
          <div className="absolute -right-24 -top-28 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
          <div className="relative flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <div className="mb-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-primary">
                <span className="status-dot h-1.5 w-1.5 rounded-full bg-primary" />
                <span>Horizonte RP · Comunidad activa</span>
              </div>
              <h1 className="font-display max-w-2xl text-3xl font-bold leading-tight tracking-tight text-foreground md:text-4xl">
                Las historias de hoy empiezan <span className="text-primary">acá.</span>
              </h1>
              <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
                El pulso de la ciudad, directo de quienes la hacen vivir. Comparte una escena, encuentra tu próximo vehículo o entra en conversación.
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-3 rounded-xl border border-border/80 bg-background/50 px-4 py-3">
              <Radio className="h-4 w-4 text-primary" />
              <div>
                <p className="font-data text-xs font-bold text-foreground">EN VIVO</p>
                <p className="text-[11px] text-muted-foreground">La ciudad está despierta</p>
              </div>
            </div>
          </div>
        </section>

        <div className="grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_18rem]">
          <div className="min-w-0 space-y-6">
            {profile?.isAdmin ? (
              <Card className="stagger-in stagger-in-2 border-primary/25 bg-card face-card">
                <CardContent className="flex items-center gap-4 p-5">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <ShieldIcon />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">Modo administrador activo</p>
                    <p className="mt-1 text-sm text-muted-foreground">Desactivá el modo administrador para publicar en la comunidad.</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="stagger-in stagger-in-2 overflow-hidden border-border/90 bg-card face-card">
                <CardContent className="p-4 md:p-5">
                  <div className="mb-4 flex items-center gap-3">
                    <Avatar className="h-10 w-10 border border-primary/40 ring-4 ring-primary/5">
                      <AvatarImage src={profile?.photo} className="object-cover" />
                      <AvatarFallback className="bg-primary/10 font-display font-bold text-primary">{profile?.name?.[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-semibold text-foreground">Comparte con la ciudad</p>
                      <p className="text-xs text-muted-foreground">Tu próxima escena puede inspirar a alguien.</p>
                    </div>
                  </div>
                  <Textarea
                    data-testid="input-post-message"
                    placeholder="¿Qué está pasando en Horizonte RP?"
                    className="min-h-[104px] resize-none border-border/70 bg-input/70 px-4 py-3 text-sm leading-relaxed transition-colors placeholder:text-muted-foreground/70 focus:border-primary/60 focus:ring-2 focus:ring-primary/10"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  />
                  {((imageMode === "url" && imageUrl) || (imageMode === "upload" && imagePreview)) && (
                    <div className="relative mt-3 inline-block animate-in fade-in zoom-in duration-300">
                      <img src={imageMode === "upload" ? imagePreview : imageUrl} alt="Vista previa del adjunto" className="h-24 w-auto rounded-xl border border-border object-cover" />
                      <Button variant="destructive" size="icon" data-testid="button-remove-attachment" className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => { setImageUrl(""); setImagePreview(""); }}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                  <div className="mt-4 flex items-center justify-between gap-3 border-t border-border/60 pt-3">
                    <Popover open={isImagePopoverOpen} onOpenChange={setIsImagePopoverOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="ghost" size="sm" data-testid="button-add-photo" className="gap-2 rounded-lg px-2 text-muted-foreground hover:bg-secondary hover:text-foreground">
                          <ImageIcon className="h-4 w-4 text-accent" />
                          Adjuntar foto
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-80 border-border bg-card p-3 face-card" align="start">
                        <Tabs value={imageMode} onValueChange={(v) => setImageMode(v as "upload" | "url")}>
                          <TabsList className="mb-3 grid w-full grid-cols-2 bg-background/80 p-1">
                            <TabsTrigger value="upload" className="gap-1.5 text-xs data-[state=active]:bg-secondary data-[state=active]:text-foreground"><Upload className="h-3 w-3" /> Adjuntar</TabsTrigger>
                            <TabsTrigger value="url" className="gap-1.5 text-xs data-[state=active]:bg-secondary data-[state=active]:text-foreground"><LinkIcon className="h-3 w-3" /> URL</TabsTrigger>
                          </TabsList>
                          <TabsContent value="upload" className="mt-0 space-y-2">
                            <Input data-testid="input-upload-image" type="file" accept="image/*" onChange={handleFileChange} className="cursor-pointer border-border/70 bg-input text-sm" />
                          </TabsContent>
                          <TabsContent value="url" className="mt-0 space-y-2">
                            <Input data-testid="input-image-url" type="url" placeholder="https://ejemplo.com/foto.jpg" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className="border-border/70 bg-input text-sm" />
                          </TabsContent>
                        </Tabs>
                      </PopoverContent>
                    </Popover>
                    <Button data-testid="button-submit-post" onClick={handleCreatePost} disabled={!message.trim() || createPost.isPending} className="gap-2 rounded-lg bg-primary px-4 font-semibold text-primary-foreground shadow-[0_8px_24px_hsl(var(--primary)/.18)] transition-transform hover:-translate-y-0.5 hover:bg-primary/90">
                      {createPost.isPending ? "Publicando..." : "Publicar"}
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="flex items-center justify-between border-b border-border/70 pb-3">
              <div>
                <p className="font-display text-lg font-bold text-foreground">Últimas historias</p>
                <p className="text-xs text-muted-foreground">Lo que está moviendo Horizonte ahora</p>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-primary"><Sparkles className="h-3.5 w-3.5" /> En tiempo real</div>
            </div>

            <div className="space-y-4">
              {isLoadingPosts ? (
                Array(3).fill(0).map((_, i) => (
                  <Card key={i} className="h-44 animate-pulse border-border/70 bg-card/80">
                    <CardContent className="space-y-4 p-5"><div className="h-4 w-32 rounded bg-secondary" /><div className="h-3 w-4/5 rounded bg-secondary" /><div className="h-20 rounded-xl bg-secondary/70" /></CardContent>
                  </Card>
                ))
              ) : posts.length === 0 ? (
                <Card className="border-dashed border-border bg-card/60">
                  <CardContent className="flex flex-col items-center justify-center px-6 py-14 text-center">
                    <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-primary/20 bg-primary/10 text-primary"><MessageCircle className="h-6 w-6" /></div>
                    <p className="font-display text-lg font-bold text-foreground">La ciudad está esperando tu primera historia</p>
                    <p className="mt-2 max-w-sm text-sm text-muted-foreground">Comparte una escena o una noticia para poner en marcha la conversación.</p>
                  </CardContent>
                </Card>
              ) : (
                posts.map((post, index) => (
                  <Card key={post.id} data-testid={`card-post-${post.id}`} className={`stagger-in stagger-in-${Math.min(index + 2, 4)} group overflow-hidden border-border/80 bg-card face-card face-card-hover`}>
                    <CardContent className="p-5 md:p-6">
                      <div className="flex items-start gap-3.5">
                        <Avatar className="mt-0.5 h-10 w-10 border border-border/80">
                          <AvatarImage src={post.authorPhoto} className="object-cover" />
                          <AvatarFallback className="bg-secondary font-display font-bold text-foreground">{post.authorName[0]}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 flex-1">
                          <div className="mb-2 flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <p className="truncate text-sm font-bold text-foreground">{post.authorName}</p>
                              <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-muted-foreground"><Clock3 className="h-3 w-3" /> {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true, locale: es })}</div>
                            </div>
                            {(profile?.isAdmin || profile?.name === post.authorName) && (
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-delete-post-${post.id}`} title="Eliminar publicación" className={`h-8 w-8 shrink-0 rounded-lg transition-colors ${profile?.isAdmin ? 'text-primary hover:bg-primary/10 hover:text-primary' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}>
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent className="border-border bg-card face-card">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>¿Eliminar publicación?</AlertDialogTitle>
                                    <AlertDialogDescription>Esta acción no se puede deshacer. La publicación se eliminará permanentemente.</AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDelete(post.id)} className="bg-primary text-primary-foreground hover:bg-primary/90">Eliminar</AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            )}
                          </div>
                          <p className="mb-4 whitespace-pre-wrap break-words text-sm leading-relaxed text-foreground/90">{post.message}</p>
                          {post.imageUrl && <div className="mb-4 max-h-[400px] overflow-hidden rounded-xl border border-border/70 bg-background"><img src={post.imageUrl} alt="Adjunto de la publicación" className="h-full w-full object-contain" loading="lazy" /></div>}
                          <div className="flex items-center gap-2 border-t border-border/60 pt-3">
                            <Button variant="ghost" size="sm" data-testid={`button-like-post-${post.id}`} className="h-8 gap-2 rounded-lg px-2.5 text-muted-foreground hover:bg-primary/10 hover:text-primary" onClick={() => handleLike(post.id)} disabled={likePost.isPending && likePost.variables?.id === post.id}>
                              <Heart className={`h-4 w-4 transition-transform group-hover:scale-110 ${post.likes > 0 ? 'fill-primary text-primary' : ''}`} />
                              <span className="text-xs font-semibold">{post.likes}</span>
                            </Button>
                            <div className="ml-auto flex items-center gap-1 text-[11px] text-muted-foreground"><MessageCircle className="h-3.5 w-3.5" /> Conversación</div>
                          </div>
                          <CommentsSection postId={post.id} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>

          <aside className="space-y-4 lg:sticky lg:top-24">
            <Card className="stagger-in stagger-in-3 border-border/80 bg-card face-card">
              <CardContent className="p-5">
                <div className="mb-5 flex items-start justify-between">
                  <div><p className="font-display text-lg font-bold text-foreground">Pulso de la ciudad</p><p className="mt-1 text-xs text-muted-foreground">Datos de la comunidad</p></div>
                  <Activity className="h-5 w-5 text-primary" />
                </div>
                <div className="space-y-2">
                  <StatRow icon={Users} label="Miembros" value={stats?.totalMembers || 0} accent />
                  <StatRow icon={Hash} label="Publicaciones" value={stats?.totalPosts || 0} />
                  <StatRow icon={Car} label="Vehículos" value={stats?.totalListings || 0} />
                  <StatRow icon={MessageCircle} label="Posts hoy" value={stats?.postsToday || 0} accent />
                </div>
              </CardContent>
            </Card>
            <Card className="stagger-in stagger-in-4 border-border/80 bg-card/70">
              <CardContent className="p-5">
                <div className="mb-3 flex items-center gap-2 text-primary"><Radio className="h-4 w-4" /><p className="text-xs font-bold uppercase tracking-[0.16em]">Ahora en Horizonte</p></div>
                <p className="text-sm leading-relaxed text-muted-foreground">La comunidad se encuentra activa. Comparte tu perspectiva y deja que la ciudad responda.</p>
                <div className="mt-4 flex items-center justify-between border-t border-border/60 pt-3 text-xs"><span className="text-muted-foreground">Actividad reciente</span><ArrowUpRight className="h-4 w-4 text-accent" /></div>
              </CardContent>
            </Card>
          </aside>
        </div>
      </div>
    </div>
  );
}

function ShieldIcon() {
  return <span className="font-data text-sm font-bold">HZ</span>;
}

function StatRow({ icon: Icon, label, value, accent = false }: { icon: typeof Users; label: string; value: number; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-border/60 bg-input/70 px-3 py-3 transition-colors hover:border-primary/30 hover:bg-secondary/60">
      <div className="flex items-center gap-3 text-sm text-muted-foreground"><Icon className={`h-4 w-4 ${accent ? "text-primary" : "text-muted-foreground"}`} /><span>{label}</span></div>
      <span className={`font-data text-sm font-bold ${accent ? "text-primary" : "text-foreground"}`}>{value}</span>
    </div>
  );
}
