import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout/layout";
import Register from "@/pages/register";
import Home from "@/pages/home";
import Marketplace from "@/pages/marketplace";
import NotFound from "@/pages/not-found";
import Admin from "@/pages/admin";
import { getProfile } from "@/lib/profile";

const queryClient = new QueryClient();

function Protected({ children }: { children: React.ReactNode }) {
  const profile = getProfile();
  if (!profile) return <Redirect to="/register" />;
  return <>{children}</>;
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={() => <Redirect to="/home" />} />
        <Route path="/register" component={Register} />
        <Route path="/home" component={() => <Protected><Home /></Protected>} />
        <Route path="/marketplace" component={() => <Protected><Marketplace /></Protected>} />
        <Route path="/admin" component={() => <Protected><Admin /></Protected>} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
