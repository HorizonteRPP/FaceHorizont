import { pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";

export const groupsTable = pgTable(
  "groups",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    photo: text("photo").notNull().default(""),
    privacy: text("privacy").notNull().default("public"),
    ownerName: text("owner_name").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    nameUnique: uniqueIndex("groups_name_unique").on(table.name),
  }),
);

export type Group = typeof groupsTable.$inferSelect;
export type InsertGroup = typeof groupsTable.$inferInsert;