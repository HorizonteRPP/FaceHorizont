import { integer, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";

export const groupMembersTable = pgTable(
  "group_members",
  {
    id: serial("id").primaryKey(),
    groupId: integer("group_id").notNull(),
    memberName: text("member_name").notNull(),
    status: text("status").notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    groupMemberUnique: uniqueIndex("group_members_unique").on(table.groupId, table.memberName),
  }),
);

export type GroupMember = typeof groupMembersTable.$inferSelect;
export type InsertGroupMember = typeof groupMembersTable.$inferInsert;