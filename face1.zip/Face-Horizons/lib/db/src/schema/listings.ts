import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const listingsTable = pgTable("listings", {
  id: serial("id").primaryKey(),
  sellerName: text("seller_name").notNull(),
  sellerPhoto: text("seller_photo").notNull(),
  carName: text("car_name").notNull(),
  price: integer("price").notNull(),
  description: text("description").notNull().default(""),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Listing = typeof listingsTable.$inferSelect;
export type InsertListing = typeof listingsTable.$inferInsert;
