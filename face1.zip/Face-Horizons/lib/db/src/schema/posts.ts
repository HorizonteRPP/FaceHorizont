import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const postsTable = pgTable("posts", {
  id: serial("id").primaryKey(),
  authorName: text("author_name").notNull(),
  authorPhoto: text("author_photo").notNull(),
  message: text("message").notNull(),
  imageUrl: text("image_url"),
  likes: integer("likes").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Post = typeof postsTable.$inferSelect;
export type InsertPost = typeof postsTable.$inferInsert;
