import { integer, pgTable, serial, text, timestamp, index } from "drizzle-orm/pg-core";

export const groupPostsTable = pgTable(
  "group_posts",
  {
    id: serial("id").primaryKey(),
    groupId: integer("group_id").notNull(),
    authorName: text("author_name").notNull(),
    authorPhoto: text("author_photo").notNull(),
    message: text("message").notNull(),
    imageUrl: text("image_url"),
    likes: integer("likes").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    groupCreatedIdx: index("group_posts_created_idx").on(table.groupId, table.createdAt),
  }),
);

export type GroupPost = typeof groupPostsTable.$inferSelect;
export type InsertGroupPost = typeof groupPostsTable.$inferInsert;