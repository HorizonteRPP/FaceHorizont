import { pgTable, serial, text, timestamp, index } from "drizzle-orm/pg-core";

export const messagesTable = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    senderName: text("sender_name").notNull(),
    recipientName: text("recipient_name").notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    readAt: timestamp("read_at", { withTimezone: true }),
  },
  (t) => [
    index("messages_sender_idx").on(t.senderName),
    index("messages_recipient_idx").on(t.recipientName),
    index("messages_created_idx").on(t.createdAt),
  ],
);

export type Message = typeof messagesTable.$inferSelect;
export type InsertMessage = typeof messagesTable.$inferInsert;
